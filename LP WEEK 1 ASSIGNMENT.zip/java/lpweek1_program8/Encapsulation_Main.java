package lpweek1_program8;

import java.util.Scanner;

public class Encapsulation_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		Data_Hiding data_hiding=new Data_Hiding();
		String name=scan.next();
		int age=scan.nextInt();
		String id=scan.next();
		data_hiding.setName(name);
		data_hiding.setAge(age);
		data_hiding.setId(id);

	      System.out.print("Name : " + data_hiding.getName() + " Age : " + data_hiding.getAge()+"ID : "+data_hiding.getId());
	      scan.close();
	}

}

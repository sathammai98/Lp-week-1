package lpweek1_program10;

import java.util.HashMap;

public class ShallowMap_Main {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap <Integer,String>original=new HashMap<Integer, String>();
		original.put(001,"AAAA");
		original.put(002,"BBB");
		original.put(003,"CCC");
		System.out.println("ORIGINAL HASH MAP CONTAINS:"+original);
		HashMap<Integer,String>duplicate=(HashMap<Integer, String>) original.clone();
		System.out.println("DYNAMIC  HASH MAP CONTAINS:"+duplicate);
		

	}

}

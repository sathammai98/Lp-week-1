package lpweek1_program14;

import java.util.Hashtable;
import java.util.Map;

public class HashTable_Main implements Runnable{
public  static Hashtable<Integer,String> hashtable=new Hashtable<Integer, String>(); 
public void run()
{
	for (Map.Entry<Integer,String>value:hashtable.entrySet())
	{
		System.out.println(value.getValue());
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hashtable.put(001,"arg1");
		hashtable.put(002,"arg2");
		hashtable.put(003,"arg3");
		
   HashTable_Main hashtable1=new  HashTable_Main();
   HashTable_Main hashtable2=new  HashTable_Main();
   Thread thread1=new Thread( hashtable1);
   Thread thread2=new Thread(hashtable2);
   thread1.start();
   thread2.start();
	}

}

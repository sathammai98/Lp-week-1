package lpweek1_program12;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapCollection_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		HashMap <Integer,String>inputMap=new HashMap<Integer, String>();
		ArrayList<String>output=new ArrayList<String>();
		inputMap.put(1,"aaaa");
		inputMap.put(2,"bbbb");
		inputMap.put(3,"cccc");
		inputMap.put(4,"dddd");
		inputMap.put(5,"eeee");
		for(Map.Entry<Integer,String>entry:inputMap.entrySet())
		{
			output.add(entry.getValue());
		}
		System.out.println(output+" ");
		scan.close();
		
		
		
		

	}

}

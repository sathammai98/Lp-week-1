package lpweek1_program7;

public class Child extends Parent {

	public Child() {
		// TODO Auto-generated constructor stub
	}
	void multiply(int value1 , int value2)
	{
		System.out.println("CHILD "+value1*value2);
	}
	
}

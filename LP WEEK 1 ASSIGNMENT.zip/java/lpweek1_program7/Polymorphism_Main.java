package lpweek1_program7;
import java.util.Scanner;

public class Polymorphism_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner scan=new Scanner(System.in);
         Parent object=new Child();
         object.multiply(100,200);
         int value1=10;
         int value2=20;
        int value3=30;
        int value=sum(value1,value2,value3);
        int final_value=sum(value1,value2); 
        System.out.println(value+" "+final_value);
        scan.close();

	}
	public static int sum(int value1,int value2,int value3)
	{
		return value1+value2+value3;
	}
	public static int sum(int value1,int value2)
	{
		return value1+value2;
	}
}

package lpweek1_program7;

public class Parent {
	Parent()
	{
		
	}
	void multiply(int value1 , int value2)
	{
		System.out.println("PARENT: "+value1*value2);
	}
	

}

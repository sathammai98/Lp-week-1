package lpweek1_program02;

import java.util.Scanner;

public class Tax_Calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner  scan=new Scanner (System.in);
	     double salary=scan.nextDouble();
	     String gender=scan.next();
	     if(salary<150000)
	     {
	    	 System.out.println("No Tax");
	     }
	      if(salary>=150000&&salary<1000000)
	      {
	    	  double tax=salary*0.10;
	    	  if(gender.equalsIgnoreCase("FEMALE"))
	    	  {
	    		  System.out.println(tax-2000);
	    	  }
	    	  System.out.printf("Tax Amount:%.2f",tax);
	      }
	      if(salary>=1000000&&salary<1500000)
	      {
	    	  double tax=salary*0.20;
	    	  if(gender.equalsIgnoreCase("FEMALE"))
	    	  {
	    		  System.out.println(tax-2000);
	    	  }
	    	  System.out.printf("Tax Amount:%.2f",tax);
	      }
	      if(salary>=1500000&&salary<3000000)
	      {
	    	  double tax=salary*0.35;
	    	  if(gender.equalsIgnoreCase("FEMALE"))
	    	  {
	    		  System.out.println(tax-2000);
	    	  }
	    	  System.out.printf("Tax Amount:%.2f",tax);
	      }
	      if(salary>=3000000)
	      {
	    	  double tax=salary*0.10;
	    	  if(gender.equalsIgnoreCase("FEMALE")) 
	    	  {
	    		  System.out.println(tax-2000);
	    	  }
	    	  System.out.printf("Tax Amount:%.2f",tax);
	      }
	      scan.close();
	      
		}

	}


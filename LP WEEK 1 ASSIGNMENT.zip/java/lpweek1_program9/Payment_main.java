package lpweek1_program9;

import java.util.Scanner;

public class Payment_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Scanner scan=new Scanner(System.in);
          System.out.println("Enter Account No:");
           long acc_no=scan.nextLong();
           System.out.println("Enter Account type:");
            String acc_type=scan.next();
            if(acc_type.equalsIgnoreCase("savings"))
            {
            SavingsAccount savings_account=new SavingsAccount(acc_no,acc_type);
            savings_account.balanceEnquiry(acc_no, acc_type);
            savings_account.accountDetails(acc_no, acc_type);
            }
            else if(acc_type.equalsIgnoreCase("curent"))
            {
            CurrentAccount current_account=new CurrentAccount(acc_no,acc_type);
            current_account.balanceEnquiry(acc_no, acc_type);
            current_account.accountDetails(acc_no, acc_type);
            }
            else
            {
            	System.out.println("Wrong Credentials !!!! Try Again");
            }
            scan.close();
          
	}

}

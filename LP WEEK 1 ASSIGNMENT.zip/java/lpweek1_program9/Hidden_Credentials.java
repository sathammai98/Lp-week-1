package lpweek1_program9;

public interface Hidden_Credentials {
	public static int ifsc_code=1111;
	public void balanceEnquiry(long acc_no,String acc_type);
	public void accountDetails(long acc_no,String acc_type);
}
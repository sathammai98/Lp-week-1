package lpweek1_program9;

public class CurrentAccount implements Hidden_Credentials {
	private long acc_no;
	private String acc_type;
	private int  acc_balance;
	CurrentAccount (long acc_no,String acc_type)
	{
		this.acc_no=acc_no;
		this.acc_type=acc_type;
	}
	
	
	public void balanceEnquiry(long acc_no,String acc_type)
	{
		acc_balance=7500000;
	}
	public void accountDetails(long acc_no,String acc_type)
	{
		if(acc_no==1111)
		 System.out.println("Name:AAA");
		else
			System.out.println("Name of the Customer:BBB");
		System.out.println("Account number of the customer: "+acc_no);
		System.out.println("Account Type of the customer: "+acc_type);
		System.out.println("IFSC Code of the branch: "+ifsc_code);   
		System.out.println("Balance in the Account"+acc_balance);
	}
	
	}



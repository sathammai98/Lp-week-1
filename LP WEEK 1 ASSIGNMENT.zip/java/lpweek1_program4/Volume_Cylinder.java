package lpweek1_program4;

public class Volume_Cylinder {
final static double PI=3.14;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int heightofCylinder=20;
        int internalDiameter=5;
        double cylinderHeight_inMeters=heightofCylinder*0.3048;
        double internalDiameter_inMeter=internalDiameter*0.3048;
        double internalRadius=internalDiameter_inMeter/2;
        double cylinder_volume=PI*internalRadius*cylinderHeight_inMeters;
        double litreToBeFilled=cylinder_volume*cylinder_volume*cylinder_volume;
        double rate_oneHour=litreToBeFilled/60;
        double rate_twoHour=litreToBeFilled/120;
        double rate_threeHour=litreToBeFilled/240;
        double rate_fourHour=litreToBeFilled/360;
        System.out.printf("Tank filled in 1 hour:%.2f\n",rate_oneHour);
        System.out.printf("Tank filled in 1 hour:%.2f\n",rate_twoHour);
        System.out.printf("Tank filled in 1 hour:%.2f\n",rate_threeHour);
        System.out.printf("Tank filled in 1 hour:%.2f\n",rate_fourHour);
	}

}
 
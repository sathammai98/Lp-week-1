package lpweek1_program15;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class List_sorting {

	public static void main(String[] args) {
	  Scanner scan = new Scanner(System.in);
	  System.out.println("Enter  NO. of input");
	  ArrayList<Integer>input=new ArrayList<Integer>();
	  ArrayList<Integer>output=new ArrayList<Integer>();
	  int length=scan.nextInt();
	 for(int i=0;i<length;i++)
		{
			int num=scan.nextInt();
			input.add(num);
			
		}
		int index=0;
		int middle=length/2;
		Collections.sort(input);
			for(Integer iterate:input)
			{
				if(index<middle)
					output.add(iterate);
				
				index++;
			}
			index=0;
			middle=length/2;
			Collections.sort(input, Collections.reverseOrder());
			for(Integer iterate:input)
			{
				if(index<=middle)
				output.add(iterate);
				index++;
			}
					
			for(Integer iterate:output)
			{
				
				System.out.print(iterate+" ");
			}
					
		scan.close();
		

	}

}

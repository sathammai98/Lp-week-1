package lpweek1_program1;

import java.util.Scanner;

public class CurrencyConversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the name of Currency:");
		String currency=scan.next();
		System.out.println("Enter the name of currency to be converted");
		String conversionCurrency=scan.next();
		double amount=scan.nextInt();
		double conversionAmount=0;
		if(currency.equalsIgnoreCase("INR"))
		{
			if(conversionCurrency.equalsIgnoreCase("INR"))
			{
				conversionAmount=amount;
			}
			else if(conversionCurrency.equalsIgnoreCase("EURO"))
			{
				conversionAmount=amount*86.32;
			}
			else if(conversionCurrency.equalsIgnoreCase("Morrocan"))
			{
				conversionAmount=amount*7.94;
			}
			else if(conversionCurrency.equalsIgnoreCase("Dirham"))
			{
				conversionAmount=amount*72.96;
			}
		}
		else if(currency.equalsIgnoreCase("EURO"))
		{
			if(conversionCurrency.equalsIgnoreCase("euro"))
			{
				conversionAmount=amount;
			}
			else if(conversionCurrency.equalsIgnoreCase("INR"))
			{
				conversionAmount=amount*0.012;
			}
			else if(conversionCurrency.equalsIgnoreCase("Morrocan"))
			{
				conversionAmount=amount*0.092;
			}
			else if(conversionCurrency.equalsIgnoreCase("Dirham"))
			{
				conversionAmount=amount*0.85;
			}
		}
		if(currency.equalsIgnoreCase("Morrocan"))
		{
			if(conversionCurrency.equalsIgnoreCase("Morrocan"))
			{
				conversionAmount=amount;
			}
			else if(conversionCurrency.equalsIgnoreCase("EURO"))
			{
				conversionAmount=amount*10.87;
			}
			else if(conversionCurrency.equalsIgnoreCase("INR"))
			{
				conversionAmount=amount*0.13;
			}
			else if(conversionCurrency.equalsIgnoreCase("Dirham"))
			{
				conversionAmount=amount*9.19;
			}
		}
		else if(currency.equalsIgnoreCase("Dirham"))
		{
			if(conversionCurrency.equalsIgnoreCase("Dirham"))
			{
				conversionAmount=amount;
			}
			else if(conversionCurrency.equalsIgnoreCase("EURO"))
			{
				conversionAmount=amount*0.85;
			}
			else if(conversionCurrency.equalsIgnoreCase("Morrocan"))
			{
				conversionAmount=amount*0.11;
			}
			else if(conversionCurrency.equalsIgnoreCase("INR"))
			{
				conversionAmount=amount*0.014;
			}
		}
		System.out.printf("Conversion amount:%.2f",conversionAmount);
		scan.close();

	}

}

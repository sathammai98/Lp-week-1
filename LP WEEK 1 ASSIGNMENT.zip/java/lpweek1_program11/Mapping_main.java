package lpweek1_program11;

import java.util.HashMap;
import java.util.Scanner;

public class Mapping_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("ENTER THE NO.OF INPUT:");
		int num=scan.nextInt();
		int[] array=new int[num];
		for(int index=0;index<num;index++)
		{
			array[index]=scan.nextInt();
		}
		HashMap<String,Integer>inputMap=new HashMap<String,Integer>();
		
		inputMap.put("AAA",array[0]);
		inputMap.put("BBB",array[1]);
		inputMap.put("CCC",array[2]);
		inputMap.put("DDD",array[3]);
		System.out.println("Do the value of AAA is present?"+"\n"+inputMap.containsKey("AAA")+" "+inputMap.get("AAA"));
		System.out.println("Do the value of "+array[0]+" is present?"+"\n"+inputMap.containsValue(array[0]));
		
         scan.close();
	}

}
 
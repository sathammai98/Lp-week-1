package lpweek1_program3;

import java.util.Scanner;

public class Scientific_Calc_Main {
	public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("ENTER INPUT DEGREE:");
	double input=scan.nextDouble();
	double radian=Math.toRadians(input);
	double sinValue=Math.sin(radian);
	double  cosValue=Math.cos(radian);
	double tanValue=Math.tan(radian);
	double squareRoot=Math.sqrt(input);
	double cubeRoot=Math.cbrt(input);
	double logValue=Math.log(input);
	System.out.println("Degree to Radian Value: "+radian);
	System.out.println("Sin Value "+sinValue);
	System.out.println("Cosine Value "+cosValue);
	System.out.println("Secant Value "+ 1/cosValue);
	System.out.println("Tan Value "+tanValue);
	System.out.println("Square Root "+squareRoot);
	System.out.println("Cube Root "+cubeRoot);
	System.out.println("Log Value "+logValue);
	scan.close();
	}

}

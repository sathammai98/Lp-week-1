package lpweek1_program6;

import java.util.Scanner;

public class AbstractionMain extends Transaction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter  your account number");
		int acc_no=scan.nextInt();
		System.out.println("Entr transferring account number");
		 final int sending_accNo=scan.nextInt();
		System.out.println(" Select one option from transferring methods\n 1.UPI\n 2.Netbanking\n 3.Credit card\n4.Wallet");
		int num=scan.nextInt();
		Transaction trans=new AbstractionMain();
		trans.payment_details(num);
		trans.display(transactionId);
        scan.close();
	}

	@Override
	public void display(int transactionId) {
		
		// TODO Auto-generated method stub
		System.out.println("THe amount from account number"+acc_no+" is transferred via "+transactionId);
		
	}

}

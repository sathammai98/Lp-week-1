package lpweek1_program6;

public abstract class Transaction implements Account_details {
      static int  transactionId=10000;
	public void payment_details(int option) {
		// TODO Auto-generated method stub
		if(option==1)
		{
			transactionId=1001;
		}
		if(option==2)
		{
			transactionId=10021;
		}
		if(option==3)
		{
			transactionId=1003;
		}
        
	}
	public abstract void display(int transactionId);

}

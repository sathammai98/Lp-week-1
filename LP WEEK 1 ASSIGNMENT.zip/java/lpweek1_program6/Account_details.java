package lpweek1_program6;

public interface Account_details {
	String name="AAA";
    int acc_no=123456789;
    int ifsc_code=0000;
    public void payment_details(int option);
    

	

}
